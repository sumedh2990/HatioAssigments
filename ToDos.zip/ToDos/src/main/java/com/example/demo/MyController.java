package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MyController 
{

	@Autowired
	ProjectRepo prepo;
	
	@Autowired
	TaskRepo trepo;
	
	@RequestMapping("projecthome")
	public String home(Model m)
	{
		List<Project> plist = prepo.findAll();
		m.addAttribute("plist", plist);
		System.out.println("i am in home");
		return "projecthome.jsp";
	}
	
	@RequestMapping("projectadd")
	public String add(Model m)
	{
		Project project = new Project();
		m.addAttribute("project", project);
		System.out.println("hello in addd");
		return "projectadd.jsp";
	}
	
	@RequestMapping("projectsave")
	public String save(Project project)
	{
		prepo.save(project);
		System.out.println("in save");
		return "redirect:projecthome";
	}
	
	@RequestMapping("projectdelete{id}")
	public String delete(@PathVariable int id)
	{
		prepo.deleteById(id);
		return "redirect:projecthome";
	}
	
	@RequestMapping("viewtask{id}")
	public String task(@PathVariable int id,Model m)
	{
		Project project = prepo.findById(id).get();
		m.addAttribute("project", project);
		return "taskhome.jsp";
	}
	
	@RequestMapping("taskadd{id}")
	public String addtask(@PathVariable int id,Model m)
	{
		
		System.out.println("in addtask");
		Project project = prepo.findById(id).get();
		Task task = new Task();
		m.addAttribute("project", project);
		m.addAttribute("task", task);
		return "taskadd.jsp";
	}
	
	@RequestMapping("tasksave{id}")
	public String savetask(Task task,@PathVariable int id)
	{
		System.out.println("i ma in tasksave");
		Project project = prepo.findById(id).get();
		project.tasks.add(task);
		prepo.save(project);
		return "redirect:viewtask"+id;
	}
	
	@RequestMapping("close{id}task{tid}")
	public String close(@PathVariable int id,@PathVariable int tid)
	{
		Project project = prepo.findById(id).get();
		for (Task t : project.tasks)
		{
			if (t.id==tid)
			{
				t.status=false;
			}
		}
		prepo.save(project);
		return "redirect:viewtask"+id;
	}
	
	@RequestMapping("task{tid}delete{pid}")
	public String deletetask(@PathVariable int tid,@PathVariable int pid)
	{
		Project project = prepo.findById(pid).get();
		Task deletetask = null;
		for (Task t : project.tasks)
		{
			if (t.id==tid)
				deletetask = t;
		}
		project.tasks.remove(deletetask);
		prepo.save(project);
		return "redirect:viewtask"+pid;
	}
	
	@RequestMapping("update{id}")
	public String update(@PathVariable int id, Model m)
	{
		Project project = prepo.getOne(id);
		m.addAttribute("project", project);
		return "projectadd.jsp";
	}
	
}
