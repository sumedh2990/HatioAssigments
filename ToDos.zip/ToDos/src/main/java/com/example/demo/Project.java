package com.example.demo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import org.springframework.data.annotation.CreatedDate;

@Entity
public class Project 
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String projectName;
	String date;
	@OneToMany(cascade = CascadeType.ALL)
	List<Task> tasks;
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Project(int id, String projectName, String date ,List<Task> tasks) {
		super();
		this.id = id;
		this.projectName = projectName;
		this.tasks = tasks;
		this.date = date;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public List<Task> getTasks() {
		return tasks;
	}
	public void setTasks(List<Task> tasks) {
		this.tasks = tasks;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Project [id=" + id + ", projectName=" + projectName + ", date=" + date + ", tasks=" + tasks + "]";
	}
	
	
}	
