package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Task 
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	String taskName;
	String created_date;
	String updated_date;
	boolean status;
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Task(int id, String taskName,String created_date,
	String updated_date, boolean status) {
		super();
		this.id = id;
		this.taskName = taskName;
		this.created_date = created_date;
		this.updated_date = updated_date; 
		this.status = status;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getCreated_date() {
		return created_date;
	}
	public void setCreated_date(String created_date) {
		this.created_date = created_date;
	}
	public String getUpdated_date() {
		return updated_date;
	}
	public void setUpdated_date(String updated_date) {
		this.updated_date = updated_date;
	}
	@Override
	public String toString() {
		return "Task [id=" + id + ", taskName=" + taskName + ", created_date=" + created_date + ", updated_date="
				+ updated_date + ", status=" + status + "]";
	}
	
	
}
